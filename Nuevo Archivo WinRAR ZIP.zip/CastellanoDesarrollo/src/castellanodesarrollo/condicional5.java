/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package castellanodesarrollo;

/**
 *
 * @author pc11
 */
public class condicional5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("mostrara todos los numeros divisibles por 2 hasta el 100");
        int a=1;
        for (a=0; a<=100; a++){
            if (a%2==0 && a%3==0)
                System.out.println(a);
        }
        
        a++;
                
    }
    
}
